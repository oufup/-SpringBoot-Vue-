package com.competition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentCompetitionServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
