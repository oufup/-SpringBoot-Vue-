package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.Apply;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


/**
 * 竞赛报名相关
 */
@RestController
@RequestMapping(value = "/apply")
public class ApplyController extends BaseController {

    /**
     * 竞赛报名分页
     * @param map
     * @return
     */
    @GetMapping
    JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = applyService.page(queryDto);
        return JSONReturn.success(pageVo);
    }


    /**
     * 根据ID查询记录
     * @param id
     * @return
     */
    @GetMapping(value = "/{id}")
    public JSONReturn selectById(@PathVariable(value = "id")Integer id){
        Apply apply = applyService.selectById(id);
        return JSONReturn.success(apply);
    }



    /**
     * 添加竞赛报名
     * @param apply
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody Apply apply){
        return applyService.save(apply);
    }


    /**
     * 更新竞赛报名
     * @param apply
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody Apply apply){
        Integer rows = applyService.update(apply);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 删除竞赛报名
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = applyService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 报名审核
     * @param apply
     * @return
     */
    @PutMapping(value = "/check")
    public JSONReturn check(@RequestBody Apply apply){
        return applyService.check(apply);
    }




    /**
     * 取消报名
     * @param id
     * @return
     */
    @GetMapping(value = "/cancel/{id}")
    public JSONReturn cancel(@PathVariable(value = "id") Integer id){
        return applyService.cancel(id);
    }



}
