package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


/**
 * 会员相关
 */
@RestController
@RequestMapping(value = "/user")
public class UserController extends BaseController {

    /**
     * 员工分页
     * @param map
     * @return
     */
    @GetMapping
    JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = userService.page(queryDto);
        return JSONReturn.success(pageVo);
    }


    /**
     * 根据ID查询记录
     * @param id
     * @return
     */
    @GetMapping(value = "/{id}")
    public JSONReturn selectById(@PathVariable(value = "id")Integer id){
        User user = userService.selectById(id);
        return JSONReturn.success(user);
    }



    /**
     * 添加员工
     * @param user
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody User user){
        return userService.save(user);
    }


    /**
     * 更新员工
     * @param user
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody User user){
        return userService.update(user);
    }



    /**
     * 删除员工
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = userService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }




    /**
     * 查询所有会员
     * @return
     */
    @GetMapping(value = "/all")
    public JSONReturn all(){
        List<User> userList = userService.findAll();
        return JSONReturn.success("查询成功！", userList);

    }



}
