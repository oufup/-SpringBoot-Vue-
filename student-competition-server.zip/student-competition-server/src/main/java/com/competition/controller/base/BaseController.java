package com.competition.controller.base;

import com.competition.service.*;
import org.springframework.beans.factory.annotation.Autowired;

public class BaseController {

    @Autowired
    public AdminService adminService;

    @Autowired
    public CollegeService collegeService;

    @Autowired
    public UserService userService;

    @Autowired
    public TeacherService teacherService;

    @Autowired
    public CategoryService categoryService;

    @Autowired
    public CompetitionService competitionService;

    @Autowired
    public ApplyService applyService;

    @Autowired
    public ProcessService processService;

    @Autowired
    public TaskService taskService;


    @Autowired
    public FeedbackService feedbackService;

    @Autowired
    public NoticeService noticeService;

}
