package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.College;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


/**
 * 学院相关
 */
@RestController
@RequestMapping(value = "/college")
public class CollegeController extends BaseController {

    /**
     * 学院分页
     * @param map
     * @return
     */
    @GetMapping
    public JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = collegeService.page(queryDto);
        return JSONReturn.success(pageVo);
    }





    /**
     * 新增学院
     * @param college
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody College college){
        Integer rows = collegeService.save(college);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 更新
     * @param college
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody College college){
        Integer rows = collegeService.update(college);
        return rows > 0 ? JSONReturn.success("更新成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 删除学院
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = collegeService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 查询所有
     * @return
     */
    @GetMapping(value = "/all")
    JSONReturn all(){
        List<College> all = collegeService.findAll();
        return JSONReturn.success(all);
    }


}
