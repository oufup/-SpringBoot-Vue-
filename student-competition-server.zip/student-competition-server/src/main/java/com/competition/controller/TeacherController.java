package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.Teacher;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


/**
 * 教师相关
 */
@RestController
@RequestMapping(value = "/teacher")
public class TeacherController extends BaseController {

    /**
     * 教师分页
     * @param map
     * @return
     */
    @GetMapping
    JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = teacherService.page(queryDto);
        return JSONReturn.success(pageVo);
    }


    /**
     * 根据ID查询记录
     * @param id
     * @return
     */
    @GetMapping(value = "/{id}")
    public JSONReturn selectById(@PathVariable(value = "id")Integer id){
        Teacher teacher = teacherService.selectById(id);
        return JSONReturn.success(teacher);
    }



    /**
     * 添加教师
     * @param teacher
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody Teacher teacher){
        return teacherService.save(teacher);
    }


    /**
     * 更新教师
     * @param teacher
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody Teacher teacher){
        return teacherService.update(teacher);
    }



    /**
     * 删除教师
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = teacherService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }




    /**
     * 查询所有教师
     * @return
     */
    @GetMapping(value = "/college/{collegeId}")
    public JSONReturn all(@PathVariable(value = "collegeId")Integer collegeId){
        List<Teacher> teacherList = teacherService.findByCollege(collegeId);
        return JSONReturn.success("查询成功！", teacherList);

    }



}
