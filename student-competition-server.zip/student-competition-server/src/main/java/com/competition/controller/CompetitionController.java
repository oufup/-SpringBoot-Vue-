package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.Competition;
import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.Map;


/**
 * 竞赛信息相关
 */
@RestController
@RequestMapping(value = "/competition")
public class CompetitionController extends BaseController {

    /**
     * 竞赛信息分页
     * @param map
     * @return
     */
    @GetMapping
    public JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = competitionService.page(queryDto);
        return JSONReturn.success(pageVo);
    }





    /**
     * 新增竞赛信息
     * @param competition
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody Competition competition){
        Integer rows = competitionService.save(competition);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 更新
     * @param competition
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody Competition competition){
        Integer rows = competitionService.update(competition);
        return rows > 0 ? JSONReturn.success("更新成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 竞赛标记开始
     * @param competition
     * @return
     */
    @PutMapping(value = "/begin")
    public JSONReturn begin(@RequestBody Competition competition){
        return competitionService.begin(competition.getId());
    }



    /**
     * 竞赛标记结束
     * @param competition
     * @return
     */
    @PutMapping(value = "/end")
    public JSONReturn end(@RequestBody Competition competition){
        return competitionService.end(competition.getId());
    }



    /**
     * 成绩公布
     * @param competition
     * @return
     */
    @PutMapping(value = "/publish")
    public JSONReturn publish(@RequestBody Competition competition){
        return competitionService.publish(competition.getId());
    }


    /**
     * 删除竞赛信息
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = competitionService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }




    /**
     * 下载附件
     * @param id
     * @return
     * @throws Exception
     */
    @GetMapping(value="/download/{id}")
    public ResponseEntity<byte[]> download(@PathVariable(value = "id") Integer id)throws Exception {

        Competition competition = competitionService.selectById(id);
        File file = new File(System.getProperty("user.dir") + competition.getFilePath());
        HttpHeaders headers = new HttpHeaders();
        //下载显示的文件名，解决中文名称乱码问题
        String downloadFielName = new String(competition.getFileName().getBytes("UTF-8"),"iso-8859-1");
        //通知浏览器以attachment（下载方式）打开图片
        headers.setContentDispositionFormData("attachment", downloadFielName);
        //application/octet-stream ： 二进制流数据（最常见的文件下载）。
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        //通过fileutils的工具输入输出下载的文件
        return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file),
                headers, HttpStatus.CREATED);
    }

}
