package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.Process;
import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.List;
import java.util.Map;


/**
 * 竞赛进程相关
 */
@RestController
@RequestMapping(value = "/process")
public class ProcessController extends BaseController {

    /**
     * 竞赛进程分页
     * @param map
     * @return
     */
    @GetMapping
    JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = processService.page(queryDto);
        return JSONReturn.success(pageVo);
    }


    /**
     * 根据ID查询记录
     * @param id
     * @return
     */
    @GetMapping(value = "/{id}")
    public JSONReturn selectById(@PathVariable(value = "id")Integer id){
        Process process = processService.selectById(id);
        return JSONReturn.success(process);
    }



    /**
     * 添加竞赛进程
     * @param process
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody Process process){
        Integer rows = processService.save(process);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 更新竞赛进程
     * @param process
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody Process process){
        Integer rows = processService.update(process);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 删除竞赛进程
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = processService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 下载作品
     * @param id
     * @return
     * @throws Exception
     */
    @GetMapping(value="/download/{id}")
    public ResponseEntity<byte[]> download(@PathVariable(value = "id") Integer id)throws Exception {

        Process process = processService.selectById(id);
        File file = new File(System.getProperty("user.dir") + process.getFilePath());
        HttpHeaders headers = new HttpHeaders();
        //下载显示的文件名，解决中文名称乱码问题
        String downloadFielName = new String(process.getFileName().getBytes("UTF-8"),"iso-8859-1");
        //通知浏览器以attachment（下载方式）打开图片
        headers.setContentDispositionFormData("attachment", downloadFielName);
        //application/octet-stream ： 二进制流数据（最常见的文件下载）。
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        //通过fileutils的工具输入输出下载的文件
        return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file),
                headers, HttpStatus.CREATED);
    }



    /**
     * 查询赛事成绩排名
     * @param competitionId
     * @return
     */
    @GetMapping(value = "/all/{competitionId}")
    JSONReturn all(@PathVariable(value = "competitionId")Integer competitionId) {
        List<Process> all = processService.findByCompetition(competitionId);
        return JSONReturn.success(all);
    }


    /**
     * 成绩公示
     * @param map
     * @return
     */
    @GetMapping(value = "/rank")
    JSONReturn rank(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = processService.rank(queryDto);
        return JSONReturn.success(pageVo);
    }


}
