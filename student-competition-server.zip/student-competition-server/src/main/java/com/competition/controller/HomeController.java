package com.competition.controller;

import com.competition.common.dto.LoginDto;
import com.competition.common.vo.CountVo;
import com.competition.common.vo.JSONReturn;
import com.competition.controller.base.BaseController;
import com.competition.utils.CodeUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.util.Base64Utils;
import org.springframework.util.FastByteArrayOutputStream;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * 主页
 */
@RestController
public class HomeController extends BaseController {

    @PostMapping(value = "/login")
    public JSONReturn<?> login(@RequestBody  LoginDto loginDto,HttpSession session){
        return userService.login(loginDto,session);
    }


    /**
     * 统计
     * @return
     */
    @GetMapping(value = "/count")
    JSONReturn count(){
        CountVo countVo = userService.count();
        return JSONReturn.success(countVo);
    }


    /**
     * 获取验证码
     *
     * @param l 验证码长度
     * @param w 宽度
     * @param h 高度
     */
    @GetMapping("/captcha/{l}/{w}/{h}")
    public JSONReturn getCaptcha(@PathVariable(value = "l") Integer l,
                                 @PathVariable(value = "w") Integer w,
                                 @PathVariable(value = "h") Integer h,
                                 HttpSession session) {

        CodeUtil codeUtil = new CodeUtil(l, w, h);
        //生成验证码
        String generatorVCode = codeUtil.generatorVCode();
        BufferedImage codeImage = codeUtil.generatorRotateVCodeImage(generatorVCode, true);
        // 转换流信息写出
        FastByteArrayOutputStream os = new FastByteArrayOutputStream();
        String base64Img = null;
        try {
            session.setAttribute("captcha",generatorVCode);
            ImageIO.write(codeImage, "gif", os);
            base64Img = Base64Utils.encodeToString(os.toByteArray());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            return JSONReturn.failed("验证码生成失败！");
        }
        return JSONReturn.success("验证码生成成功！", base64Img);
    }


}
