package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.Category;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


/**
 * 竞赛类别相关
 */
@RestController
@RequestMapping(value = "/category")
public class CategoryController extends BaseController {

    /**
     * 竞赛类别分页
     * @param map
     * @return
     */
    @GetMapping
    public JSONReturn page(@RequestParam Map<String,Object> map){
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = categoryService.page(queryDto);
        return JSONReturn.success(pageVo);
    }





    /**
     * 新增竞赛类别
     * @param category
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody Category category){
        Integer rows = categoryService.save(category);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 更新
     * @param category
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody Category category){
        Integer rows = categoryService.update(category);
        return rows > 0 ? JSONReturn.success("更新成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 删除竞赛类别
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id")Integer id){
        Integer rows = categoryService.del(id);
        return rows  > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 查询所有
     * @return
     */
    @GetMapping(value = "/all")
    JSONReturn all(){
        List<Category> all = categoryService.findAll();
        return JSONReturn.success(all);
    }


}
