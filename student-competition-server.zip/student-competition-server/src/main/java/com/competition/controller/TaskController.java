package com.competition.controller;

import com.competition.common.dto.PageQueryDto;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.controller.base.BaseController;
import com.competition.entity.Task;
import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.List;
import java.util.Map;


/**
 * 参赛进展相关
 */
@RestController
@RequestMapping(value = "/task")
public class TaskController extends BaseController {

    /**
     * 参赛进展分页
     * @param map
     * @return
     */
    @GetMapping
    JSONReturn page(@RequestParam Map<String, Object> map) {
        PageQueryDto queryDto = new PageQueryDto(map);
        PageVo pageVo = taskService.page(queryDto);
        return JSONReturn.success(pageVo);
    }

    /**
     * 新增参赛进展
     * @param task
     * @return
     */
    @PostMapping
    public JSONReturn save(@RequestBody Task task) {
        Integer rows = taskService.save(task);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 更新
     *
     * @param task
     * @return
     */
    @PutMapping
    public JSONReturn update(@RequestBody Task task) {
        Integer rows = taskService.update(task);
        return rows > 0 ? JSONReturn.success("保存成功！") : JSONReturn.failed("操作失败！");
    }


    /**
     * 删除参赛进展
     *
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public JSONReturn delete(@PathVariable(value = "id") Integer id) {
        Integer rows = taskService.del(id);
        return rows > 0 ? JSONReturn.success("删除成功！") : JSONReturn.failed("操作失败！");
    }



    /**
     * 查询任务
     * @param processId
     * @return
     */
    @GetMapping(value = "/process/{processId}")
    JSONReturn all(@PathVariable(value = "processId")Integer processId) {
        List<Task> all = taskService.findByProcess(processId);
        return JSONReturn.success(all);
    }



    /**
     * 下载作品
     * @param id
     * @return
     * @throws Exception
     */
    @GetMapping(value="/download/{id}")
    public ResponseEntity<byte[]> download(@PathVariable(value = "id") Integer id)throws Exception {

        Task task = taskService.selectById(id);
        File file = new File(System.getProperty("user.dir") + task.getFilePath());
        HttpHeaders headers = new HttpHeaders();
        //下载显示的文件名，解决中文名称乱码问题
        String downloadFielName = new String(task.getFileName().getBytes("UTF-8"),"iso-8859-1");
        //通知浏览器以attachment（下载方式）打开图片
        headers.setContentDispositionFormData("attachment", downloadFielName);
        //application/octet-stream ： 二进制流数据（最常见的文件下载）。
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        //通过fileutils的工具输入输出下载的文件
        return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file),
                headers, HttpStatus.CREATED);
    }

}
