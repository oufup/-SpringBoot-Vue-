package com.competition.common.dto;

/**
 * 登录请求参数
 */
public class LoginDto {

    /**
     * 账号
     */
    private String username;



    /**
     * 密码
     */
    private String password;


    /**
     * 验证码
     */
    private String captcha;


    /**
     * 角色：0管理员，1物业，2业主
     */
    private Integer role;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }
}
