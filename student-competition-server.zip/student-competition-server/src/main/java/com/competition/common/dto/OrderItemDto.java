package com.competition.common.dto;


import java.util.List;

/**
 * 销售单明细参数
 */
public class OrderItemDto {

    private Integer orderId;

    private List<Integer> itemList;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public List<Integer> getItemList() {
        return itemList;
    }

    public void setItemList(List<Integer> itemList) {
        this.itemList = itemList;
    }
}
