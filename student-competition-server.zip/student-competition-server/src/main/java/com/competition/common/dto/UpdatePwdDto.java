package com.competition.common.dto;

/**
 * 密码修改
 */
public class UpdatePwdDto {

    /**
     * ID
     */
    private Integer id;

    /**
     * 原始密码
     */
    private String oldPwd;

    /**
     * 新的密码
     */
    private String password;


    /**
     * 身份：0管理员，1员工，2会员
     */
    private Integer role;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOldPwd() {
        return oldPwd;
    }

    public void setOldPwd(String oldPwd) {
        this.oldPwd = oldPwd;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }
}
