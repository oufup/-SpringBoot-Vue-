package com.competition.common.vo;

import com.competition.entity.Notice;

import java.util.List;

/**
 * 统计
 */
public class CountVo {


    /**
     * 公告
     */
    private List<Notice> noticeList;


    /**
     * 竞赛统计
     */
    private List<CompetitionVo> competitionList;


    /**
     * 过去7天
     */
    private String[] dayList;


    /**
     * 过去7天报名人数
     */
    private List<Integer> applyNumList;


    public List<Notice> getNoticeList() {
        return noticeList;
    }

    public void setNoticeList(List<Notice> noticeList) {
        this.noticeList = noticeList;
    }

    public List<CompetitionVo> getCompetitionList() {
        return competitionList;
    }

    public void setCompetitionList(List<CompetitionVo> competitionList) {
        this.competitionList = competitionList;
    }

    public String[] getDayList() {
        return dayList;
    }

    public void setDayList(String[] dayList) {
        this.dayList = dayList;
    }

    public List<Integer> getApplyNumList() {
        return applyNumList;
    }

    public void setApplyNumList(List<Integer> applyNumList) {
        this.applyNumList = applyNumList;
    }
}
