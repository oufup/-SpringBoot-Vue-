package com.competition.common.dto;

/**
 * 人脸识别登录
 */
public class FaceLoginDto {

    private String base;

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }
}
