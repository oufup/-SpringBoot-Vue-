package com.competition.common.vo;

/**
 * 竞赛统计
 */
public class CompetitionVo {

    /**
     * 分类名称
     */
    private String name;

    /**
     * 竞赛数量
     */
    private Integer value;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
