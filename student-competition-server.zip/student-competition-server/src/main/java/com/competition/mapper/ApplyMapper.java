package com.competition.mapper;

import com.competition.entity.Apply;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 竞赛报名申请持久化层
 */
public interface ApplyMapper {
    /**
     * 根据ID删除记录
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 全量字段保存记录
     * @param record
     * @return
     */
    int insert(Apply record);

    /**
     * 部分字段保存记录
     * @param record
     * @return
     */
    int insertSelective(Apply record);

    /**
     * 根据Id查询记录
     * @param id
     * @return
     */
    Apply selectByPrimaryKey(Integer id);

    /**
     * 部分字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Apply record);

    /**
     * 全部字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKey(Apply record);


    /**
     * 查询记录
     * @param map
     * @return
     */
    List<Apply> findList(Map map);


    /**
     * 统计记录
     * @param map
     * @return
     */
    Integer findTotal(Map map);


    /**
     * 查询是否已报名
     * @param userId 学生ID
     * @param competitionId 竞赛ID
     * @return
     */
    Apply selectExist(@Param(value = "userId")Integer userId, @Param(value = "competitionId")Integer competitionId);


    /**
     * 查询所有报名并审核通过的记录
     * @param competitionId
     * @return
     */
    List<Apply> findPassList(@Param(value = "competitionId")Integer competitionId);



    /**
     * 统计报名人数
     * @param beginTime
     * @param endTime
     * @return
     */
    Integer countByDate(@Param(value = "beginTime")String beginTime, @Param(value = "endTime")String endTime);
}