package com.competition.mapper;

import com.competition.entity.College;

import java.util.List;
import java.util.Map;

/**
 * 学院信息持久化层
 */
public interface CollegeMapper {
    /**
     * 根据ID删除记录
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 全量字段保存记录
     * @param record
     * @return
     */
    int insert(College record);

    /**
     * 部分字段保存记录
     * @param record
     * @return
     */
    int insertSelective(College record);

    /**
     * 根据Id查询记录
     * @param id
     * @return
     */
    College selectByPrimaryKey(Integer id);

    /**
     * 部分字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(College record);

    /**
     * 全部字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKey(College record);


    /**
     * 查询记录
     * @param map
     * @return
     */
    List<College> findList(Map map);


    /**
     * 统计记录
     * @param map
     * @return
     */
    Integer findTotal(Map map);


    /**
     * 查询所有种类
     * @return
     */
    List<College> findAll();
}