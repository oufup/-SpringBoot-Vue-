package com.competition.mapper;

import com.competition.entity.Category;

import java.util.List;
import java.util.Map;

/**
 * 竞赛类别持久化层
 */
public interface CategoryMapper {
    /**
     * 根据ID删除记录
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 全量字段保存记录
     * @param record
     * @return
     */
    int insert(Category record);

    /**
     * 部分字段保存记录
     * @param record
     * @return
     */
    int insertSelective(Category record);

    /**
     * 根据Id查询记录
     * @param id
     * @return
     */
    Category selectByPrimaryKey(Integer id);

    /**
     * 部分字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Category record);

    /**
     * 全部字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKey(Category record);


    /**
     * 查询记录
     * @param map
     * @return
     */
    List<Category> findList(Map map);


    /**
     * 统计记录
     * @param map
     * @return
     */
    Integer findTotal(Map map);


    /**
     * 查询所有种类
     * @return
     */
    List<Category> findAll();
}