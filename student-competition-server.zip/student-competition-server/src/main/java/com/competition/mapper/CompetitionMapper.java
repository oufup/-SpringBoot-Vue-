package com.competition.mapper;

import com.competition.entity.Competition;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 竞赛信息持久化层
 */
public interface CompetitionMapper {
    /**
     * 根据ID删除记录
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 全量字段保存记录
     * @param record
     * @return
     */
    int insert(Competition record);

    /**
     * 部分字段保存记录
     * @param record
     * @return
     */
    int insertSelective(Competition record);

    /**
     * 根据Id查询记录
     * @param id
     * @return
     */
    Competition selectByPrimaryKey(Integer id);

    /**
     * 部分字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Competition record);

    /**
     * 全部字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKey(Competition record);


    /**
     * 查询记录
     * @param map
     * @return
     */
    List<Competition> findList(Map map);


    /**
     * 统计记录
     * @param map
     * @return
     */
    Integer findTotal(Map map);


    /**
     * 统计分类下竞赛数量
     * @param categoryId
     * @return
     */
    Integer countByCategory(@Param(value = "categoryId")Integer categoryId);
}