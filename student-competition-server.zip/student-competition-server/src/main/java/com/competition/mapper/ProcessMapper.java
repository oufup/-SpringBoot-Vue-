package com.competition.mapper;

import com.competition.entity.Process;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 竞赛进程持久化层
 */
public interface ProcessMapper {
    /**
     * 根据ID删除记录
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 全量字段保存记录
     * @param record
     * @return
     */
    int insert(Process record);

    /**
     * 部分字段保存记录
     * @param record
     * @return
     */
    int insertSelective(Process record);

    /**
     * 根据Id查询记录
     * @param id
     * @return
     */
    Process selectByPrimaryKey(Integer id);

    /**
     * 部分字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Process record);

    /**
     * 全部字段更新记录信息
     * @param record
     * @return
     */
    int updateByPrimaryKey(Process record);


    /**
     * 查询记录
     * @param map
     * @return
     */
    List<Process> findList(Map map);


    /**
     * 统计记录
     * @param map
     * @return
     */
    Integer findTotal(Map map);


    /**
     * 查询成绩公示记录
     * @param map
     * @return
     */
    List<Process> findRankList(Map map);


    /**
     * 统计成绩公示记录
     * @param map
     * @return
     */
    Integer findRankTotal(Map map);


    /**
     * 更新竞赛者竞赛过程
     * @param competitionId
     * @param status
     * @return
     */
    Integer updateByCompetition(@Param(value = "competitionId")Integer competitionId,@Param(value = "status")Integer status);


    /**
     * 查询竞赛排名
     * @param competitionId
     * @return
     */
    List<Process> findByCompetition(@Param(value = "competitionId")Integer competitionId);
}