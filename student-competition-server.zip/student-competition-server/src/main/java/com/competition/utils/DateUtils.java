package com.competition.utils;

import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 日期工具类
 */
public class DateUtils {


    public static final String DATE_PATTERN = "yyyy-MM-dd";


    /**
     * 时间格式化成字符串
     *
     * @param date    Date
     * @param pattern StrUtils.DATE_TIME_PATTERN || StrUtils.DATE_PATTERN， 如果为空，则为yyyy-MM-dd
     * @return
     * @throws ParseException
     */
    public static String dateFormat(Date date, String pattern) {
        if (StringUtils.isEmpty(pattern)) {
            pattern = DateUtils.DATE_PATTERN;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    /**
     * 字符串解析成时间对象
     *
     * @param dateTimeString String
     * @param pattern        StrUtils.DATE_TIME_PATTERN || StrUtils.DATE_PATTERN，如果为空，则为yyyy-MM-dd
     * @return
     * @throws ParseException
     */
    public static Date dateParse(String dateTimeString, String pattern) {
        if (StringUtils.isEmpty(pattern)) {
            pattern = DateUtils.DATE_PATTERN;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            return sdf.parse(dateTimeString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static int getAgeByBirth(Date birthday) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            birthday = sdf.parse(sdf.format(birthday));
            //Calendar：日历
            /*从Calendar对象中或得一个Date对象*/
            Calendar cal = Calendar.getInstance();
            /*把出生日期放入Calendar类型的bir对象中，进行Calendar和Date类型进行转换*/
            Calendar bir = Calendar.getInstance();
            bir.setTime(birthday);
            /*如果生日大于当前日期，则抛出异常：出生日期不能大于当前日期*/
            if (cal.before(birthday)) {
                throw new IllegalArgumentException("The birthday is before Now,It's unbelievable");
            }
            /*取出当前年月日*/
            int yearNow = cal.get(Calendar.YEAR);
            int monthNow = cal.get(Calendar.MONTH);
            int dayNow = cal.get(Calendar.DAY_OF_MONTH);
            /*取出出生年月日*/
            int yearBirth = bir.get(Calendar.YEAR);
            int monthBirth = bir.get(Calendar.MONTH);
            int dayBirth = bir.get(Calendar.DAY_OF_MONTH);
            /*大概年龄是当前年减去出生年*/
            int age = yearNow - yearBirth;
            /*如果出当前月小与出生月，或者当前月等于出生月但是当前日小于出生日，那么年龄age就减一岁*/
            if (monthNow < monthBirth || (monthNow == monthBirth && dayNow < dayBirth)) {
                age--;
            }
            return age;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return -1;

    }


    /**
     * 通过秒毫秒数判断两个时间的间隔的天数
     *
     * @param min
     * @param max
     * @return
     */
    public static int differDays(Date min, Date max) {
        int days = (int) ((max.getTime() - min.getTime()) / (1000 * 3600 * 24));
        return days;
    }


    /**
     * 获取过去12个月
     */
    public static String[] getLast12Months() {
        String[] last12Months = new String[12];
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) + 1); //要先+1,才能把本月的算进去
        for (int i = 0; i < 12; i++) {
            cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - 1); //逐次往前推1个月
            last12Months[11 - i] = cal.get(Calendar.YEAR) + "-" + fillZero((cal.get(Calendar.MONTH) + 1));
        }
        return last12Months;
    }


    /**
     * 获取指定月份的最后一天
     * @param month 格式为 yyyy-MM 的字符串
     * @return 格式为 yyyy-MM-dd 的字符串，表示该月的最后一天
     * @throws DateTimeParseException 如果输入格式不正确
     */
    public static String getLastDayOfMonth(String month){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            Date date = sdf.parse(month);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
            return outputFormat.format(calendar.getTime());
        }catch (ParseException e){
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取指定月份的第一天
     *
     * @param month 格式为 yyyy-MM 的字符串
     * @return 格式为 yyyy-MM-dd 的字符串，表示该月的第一天
     * @throws DateTimeParseException 如果输入格式不正确
     */
    public static String getFirstDayOfMonth(String month){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            Date date = sdf.parse(month);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
            return outputFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 获取过去七天
     *
     * @return
     */
    public static List<String> getPastSevenDays() {
        List<String> pastSevenDays = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        for (int i = 6; i >= 0; i--) {
            calendar.setTime(new Date());
            calendar.add(Calendar.DATE, -i);
            Date dateTime = calendar.getTime();
            String day = DateUtils.dateFormat(dateTime, "yyyy-MM-dd");
            pastSevenDays.add(day);
        }
        return pastSevenDays;
    }


    /**
     * 计算两个日期之差（天、时、分）
     *
     * @param endDate
     * @param nowDate
     * @return
     */
    public static Long[] getDateBetweenHour(Date endDate, Date nowDate) {

        long nd = 1000 * 24 * 60 * 60;// 1天天多少毫秒?
        long nh = 1000 * 60 * 60;// 1个小时多少毫秒?
        long nm = 1000 * 60;// 1分钟多少毫秒
        // long ns = 1000;
        // 获得两个时间的毫秒时间差?
        long diff = endDate.getTime() - nowDate.getTime();
        // 计算差多少天
        long day = diff / nd;
        // 计算差多少小时?
        long hour = diff % nd / nh;
        // 计算差多少分钟?
        long min = diff % nd % nh / nm;
        // 计算差多少秒//输出结果
        // long sec = diff % nd % nh % nm / ns;
        Long[] res = new Long[3];
        res[0] = day;
        res[1] = hour;
        res[2] = min;
        return res;
    }


    /**
     * 计算两个时间之间相差分钟
     *
     * @param time1
     * @param time2
     * @return
     */
    public static long calculateMinutes(Date time1, Date time2) {
        LocalDateTime beginTime = LocalDateTime.ofInstant(time1.toInstant(), ZoneId.systemDefault());
        LocalDateTime endTime = LocalDateTime.ofInstant(time2.toInstant(), ZoneId.systemDefault());
        long minutes = ChronoUnit.MINUTES.between(beginTime, endTime);
        return minutes;
    }


    /**
     * 获取过去7天
     *
     * @return
     */
    public static String[] getPast7Days() {

        String[] days = new String[7];
        Calendar calendar = Calendar.getInstance();
        for (int i = 6; i >= 0; i--) {
            calendar.setTime(new Date());
            calendar.add(Calendar.DATE, -i);
            Date dateTime = calendar.getTime();
            String day = DateUtils.dateFormat(dateTime, DateUtils.DATE_PATTERN);
            days[6 - i] = day;
        }
        return days;
    }


    /**
     * 格式化月份
     */
    public static String fillZero(int i) {
        String month = "";
        if (i < 10) {
            month = "0" + i;
        } else {
            month = String.valueOf(i);
        }
        return month;
    }

    public static void main(String[] args) {

    }
}
