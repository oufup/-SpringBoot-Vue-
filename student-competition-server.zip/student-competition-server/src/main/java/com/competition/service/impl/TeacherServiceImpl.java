package com.competition.service.impl;

import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.Teacher;
import com.competition.mapper.TeacherMapper;
import com.competition.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 教师服务实现类
 */
@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    
    @Override
    public PageVo page(Map map) {
        List<Teacher> list = teacherMapper.findList(map);
        Integer total = teacherMapper.findTotal(map);
        return new PageVo(total, list);
    }

    @Override
    public JSONReturn save(Teacher teacher) {
        //账号查询
        Teacher exist = teacherMapper.selectByUsername(teacher.getUsername());
        if (exist != null) {
            return JSONReturn.failed("工号已存在，请重新输入！");
        }
        Date date = new Date();
        teacher.setStatus(0);
        //初始化性别
        teacher.setSex(0);
        teacher.setCreateTime(date);
        teacher.setUpdateTime(date);
        teacherMapper.insert(teacher);
        return JSONReturn.success("注册成功！");
    }

    @Override
    public JSONReturn update(Teacher teacher) {

        Teacher u = teacherMapper.selectByPrimaryKey(teacher.getId());
        if (teacher.getUsername() != null && !u.getUsername().equals(teacher.getUsername())) {
            Teacher exist = teacherMapper.selectByUsername(teacher.getUsername());
            if (exist != null) {
                return JSONReturn.failed("工号已存在，请重新输入！");
            }
        }
        teacher.setUpdateTime(new Date());
        teacherMapper.updateByPrimaryKeySelective(teacher);
        return JSONReturn.success("保存成功！");
    }


    @Override
    public Integer del(Integer id) {
        return teacherMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Teacher selectById(Integer id) {
        return teacherMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Teacher> findByCollege(Integer collegeId) {
        return teacherMapper.findByCollege(collegeId);
    }


}
