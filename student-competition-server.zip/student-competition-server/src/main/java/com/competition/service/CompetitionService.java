package com.competition.service;

import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.Competition;

import java.util.Map;

/**
 * 竞赛信息服务类
 */
public interface CompetitionService {

    /**
     * 竞赛信息分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加竞赛信息
     * @param competition
     * @return
     */
    Integer save(Competition competition);

    /**
     * 更新竞赛信息
     * @param competition
     * @return
     */
    Integer update(Competition competition);



    /**
     * 竞赛开始
     * @param id
     * @return
     */
    JSONReturn begin(Integer id);



    /**
     * 竞赛结束
     * @param id
     * @return
     */
    JSONReturn end(Integer id);


    /**
     * 成绩公布
     * @param id
     * @return
     */
    JSONReturn publish(Integer id);



    /**
     * 删除竞赛信息
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询竞赛信息
     * @param id
     * @return
     */
    Competition selectById(Integer id);



}
