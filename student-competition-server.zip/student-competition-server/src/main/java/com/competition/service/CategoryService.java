package com.competition.service;

import com.competition.common.vo.PageVo;
import com.competition.entity.Category;

import java.util.List;
import java.util.Map;

/**
 * 竞赛类别服务类
 */
public interface CategoryService {

    /**
     * 竞赛类别分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加竞赛类别
     * @param category
     * @return
     */
    Integer save(Category category);

    /**
     * 更新竞赛类别
     * @param category
     * @return
     */
    Integer update(Category category);


    /**
     * 删除竞赛类别
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询竞赛类别
     * @param id
     * @return
     */
    Category selectById(Integer id);


    /**
     * 查询所有竞赛类别
     * @return
     */
    List<Category> findAll();



}
