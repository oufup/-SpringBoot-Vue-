package com.competition.service;

import com.competition.common.vo.PageVo;
import com.competition.entity.Task;

import java.util.List;
import java.util.Map;

/**
 * 参赛进展服务层
 */
public interface TaskService {

    /**
     * 参赛进展分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加参赛进展
     * @param task
     * @return
     */
    Integer save(Task task);

    /**
     * 更新参赛进展
     * @param task
     * @return
     */
    Integer update(Task task);


    /**
     * 删除参赛进展
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询参赛进展
     * @param id
     * @return
     */
    Task selectById(Integer id);



    /**
     * 查询任务
     * @param processId 进程ID
     * @return
     */
    List<Task> findByProcess(Integer processId);
}
