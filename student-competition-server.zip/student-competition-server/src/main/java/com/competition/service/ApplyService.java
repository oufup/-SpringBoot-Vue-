package com.competition.service;

import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.Apply;

import java.util.Map;


/**
 * 竞赛报名服务类
 */
public interface ApplyService {
    

    /**
     * 竞赛报名分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加竞赛报名
     * @param apply
     * @return
     */
    JSONReturn save(Apply apply);


    /**
     * 修改
     * @param apply
     * @return
     */
    Integer update(Apply apply);



    /**
     * 删除竞赛报名
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询竞赛报名信息
     * @param id
     * @return
     */
    Apply selectById(Integer id);



    /**
     * 报名审核
     * @param apply
     * @return
     */
    JSONReturn check(Apply apply);



    /**
     * 取消报名
     * @param id
     * @return
     */
    JSONReturn cancel(Integer id);

}
