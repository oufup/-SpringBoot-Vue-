package com.competition.service.impl;

import com.competition.common.vo.PageVo;
import com.competition.entity.Category;
import com.competition.mapper.CategoryMapper;
import com.competition.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 竞赛类别实现类
 */
@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryMapper categoryMapper;

    @Override
    public PageVo page(Map map) {
        List<Category> list = categoryMapper.findList(map);
        Integer total = categoryMapper.findTotal(map);
        return new PageVo(total,list);
    }

    @Override
    public Integer save(Category category) {
        Date date = new Date();
        category.setCreateTime(date);
        category.setUpdateTime(date);
        return categoryMapper.insert(category);
    }

    @Override
    public Integer update(Category category) {
        category.setUpdateTime(new Date());
        return categoryMapper.updateByPrimaryKeySelective(category);
    }

    @Override
    public Integer del(Integer id) {
        return categoryMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Category selectById(Integer id) {
        return categoryMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Category> findAll() {
        return categoryMapper.findAll();
    }
}
