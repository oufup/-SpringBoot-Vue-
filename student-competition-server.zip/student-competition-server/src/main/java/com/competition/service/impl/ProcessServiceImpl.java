package com.competition.service.impl;

import com.competition.common.vo.PageVo;
import com.competition.entity.Process;
import com.competition.mapper.ProcessMapper;
import com.competition.service.ProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 竞赛进程服务实现类
 */
@Service
public class ProcessServiceImpl implements ProcessService {

    @Autowired
    private ProcessMapper processMapper;


    @Override
    public PageVo page(Map map) {
        List<Process> list = processMapper.findList(map);
        Integer total = processMapper.findTotal(map);
        return new PageVo(total,list);
    }

    @Override
    public Integer save(Process process) {
        Date date = new Date();
        process.setCreateTime(date);
        process.setUpdateTime(date);
        process.setStatus(0);
        return processMapper.insert(process);
    }

    @Override
    public Integer update(Process process) {

        process.setUpdateTime(new Date());
        return processMapper.updateByPrimaryKeySelective(process);
    }

    @Override
    public Integer del(Integer id) {
        return processMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Process selectById(Integer id) {
        return processMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Process> findByCompetition(Integer competitionId) {
        return processMapper.findByCompetition(competitionId);
    }

    @Override
    public PageVo rank(Map map) {
        List<Process> list = processMapper.findRankList(map);
        Integer total = processMapper.findRankTotal(map);
        return new PageVo(total,list);
    }
}
