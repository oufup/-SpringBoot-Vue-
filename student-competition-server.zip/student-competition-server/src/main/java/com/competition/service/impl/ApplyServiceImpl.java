package com.competition.service.impl;

import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.Apply;
import com.competition.mapper.ApplyMapper;
import com.competition.service.ApplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 竞赛报名服务实现类
 */
@Service
public class ApplyServiceImpl implements ApplyService {

    @Autowired
    private ApplyMapper applyMapper;


    @Override
    public PageVo page(Map map) {
        List<Apply> list = applyMapper.findList(map);
        Integer total = applyMapper.findTotal(map);
        return new PageVo(total,list);
    }

    @Override
    public JSONReturn save(Apply apply) {
        //查询是否已报名
        Apply exist = applyMapper.selectExist(apply.getUserId(),apply.getCompetitionId());
        if(exist != null){
            return JSONReturn.failed("您已报名该竞赛，请耐心等待审核！");
        }
        Date date = new Date();
        apply.setCreateTime(date);
        apply.setUpdateTime(date);
        apply.setStatus(0);
        applyMapper.insert(apply);
        return JSONReturn.success("保存成功！");
    }

    @Override
    public Integer update(Apply apply) {

        apply.setUpdateTime(new Date());
        return applyMapper.updateByPrimaryKeySelective(apply);
    }

    @Override
    public Integer del(Integer id) {
        return applyMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Apply selectById(Integer id) {
        return applyMapper.selectByPrimaryKey(id);
    }

    @Override
    public JSONReturn check(Apply apply) {

        Apply a = applyMapper.selectByPrimaryKey(apply.getId());
        if(a.getStatus() !=0){
            return JSONReturn.failed("操作失败，该报名申请已审核！");
        }
        applyMapper.updateByPrimaryKeySelective(apply);
        return JSONReturn.success("审核成功！");
    }

    @Override
    public JSONReturn cancel(Integer id) {

        Apply apply = applyMapper.selectByPrimaryKey(id);
        if(apply.getStatus() != 0){
            return JSONReturn.failed("取消，该报名申请已审核！");
        }
        return null;
    }
}
