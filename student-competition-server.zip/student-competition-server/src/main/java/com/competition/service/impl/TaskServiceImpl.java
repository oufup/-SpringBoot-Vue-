package com.competition.service.impl;

import com.competition.common.vo.PageVo;
import com.competition.entity.Task;
import com.competition.mapper.TaskMapper;
import com.competition.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 任务服务实现类
 */
@Service
public class TaskServiceImpl implements TaskService {

    @Autowired
    private TaskMapper taskMapper;


    @Override
    public PageVo page(Map map) {
        List<Task> list = taskMapper.findList(map);
        Integer total = taskMapper.findTotal(map);
        return new PageVo(total,list);
    }

    @Override
    public Integer save(Task task) {
        Date date = new Date();
        task.setStatus(0);
        task.setCreateTime(date);
        task.setUpdateTime(date);
        return taskMapper.insert(task);
    }

    @Override
    public Integer update(Task task) {
        task.setUpdateTime(new Date());
        return taskMapper.updateByPrimaryKeySelective(task);
    }

    @Override
    public Integer del(Integer id) {
        return taskMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Task selectById(Integer id) {
        return taskMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Task> findByProcess(Integer processId) {
        return taskMapper.findByProcess(processId);
    }

}
