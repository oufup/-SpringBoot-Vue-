package com.competition.service;

import com.competition.common.vo.PageVo;
import com.competition.entity.Process;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


/**
 * 比赛进程服务类
 */
public interface ProcessService {
    

    /**
     * 比赛进程分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加比赛进程
     * @param Process
     * @return
     */
    Integer save(Process Process);


    /**
     * 修改
     * @param Process
     * @return
     */
    Integer update(Process Process);



    /**
     * 删除比赛进程
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询比赛进程信息
     * @param id
     * @return
     */
    Process selectById(Integer id);


    /**
     * 查询竞赛成绩排名
     * @param competitionId
     * @return
     */
    List<Process> findByCompetition(@Param(value = "competitionId")Integer competitionId);



    /**
     * 成绩公示
     * @param map
     * @return
     */
    PageVo rank(Map map);

}
