package com.competition.service.impl;

import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.Apply;
import com.competition.entity.Competition;
import com.competition.entity.Process;
import com.competition.mapper.ApplyMapper;
import com.competition.mapper.CompetitionMapper;
import com.competition.mapper.ProcessMapper;
import com.competition.service.CompetitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 竞赛信息实现类
 */
@Service
public class CompetitionServiceImpl implements CompetitionService {

    @Autowired
    private CompetitionMapper competitionMapper;

    @Autowired
    private ApplyMapper applyMapper;

    @Autowired
    private ProcessMapper processMapper;

    @Override
    public PageVo page(Map map) {
        List<Competition> list = competitionMapper.findList(map);
        Integer total = competitionMapper.findTotal(map);
        return new PageVo(total,list);
    }

    @Override
    public Integer save(Competition competition) {
        Date date = new Date();
        competition.setStatus(0);
        competition.setCreateTime(date);
        competition.setUpdateTime(date);
        return competitionMapper.insert(competition);
    }

    @Override
    public Integer update(Competition competition) {
        competition.setUpdateTime(new Date());
        return competitionMapper.updateByPrimaryKeySelective(competition);
    }

    @Override
    public JSONReturn begin(Integer id) {
        Competition c = competitionMapper.selectByPrimaryKey(id);
        if(c.getStatus() != 0){
            return JSONReturn.failed("操作失败，该竞赛进行中或已结束！");
        }
        //查询所有报名并审核通过的记录
        List<Apply> passList = applyMapper.findPassList(id);
        //分别生成赛事进程记录，为后续上传作品，作品评审用
        for(Apply apply : passList){
            Process process = new Process();
            process.setUserId(apply.getUserId());
            process.setCompetitionId(id);
            process.setTeacherId(apply.getTeacherId());
            process.setStatus(0);
            process.setPrize(0);
            Date date = new Date();
            process.setCreateTime(date);
            process.setUpdateTime(date);
            processMapper.insert(process);
        }
        // 竞赛状态设置为进行中
        c.setStatus(1);
        competitionMapper.updateByPrimaryKeySelective(c);
        return JSONReturn.success("操作成功！");
    }

    @Override
    public JSONReturn end(Integer id) {
        Competition c = competitionMapper.selectByPrimaryKey(id);
        if(c.getStatus() != 1){
            return JSONReturn.failed("操作失败，该竞赛暂未开始或已结束！");
        }
        //将所有赛事进程状态设置为已结束
        processMapper.updateByCompetition(id,1);
        //竞赛状态设置为已结束
        c.setStatus(2);
        competitionMapper.updateByPrimaryKeySelective(c);
        return JSONReturn.success("操作成功！");
    }

    @Override
    public JSONReturn publish(Integer id) {
        Competition c = competitionMapper.selectByPrimaryKey(id);
        if(c.getStatus() != 2){
            return JSONReturn.failed("操作失败，该竞赛暂未开始或已结束！");
        }
        //将所有赛事进程状态设置为已公示
        processMapper.updateByCompetition(id,3);
        //竞赛状态设置为已公示
        c.setStatus(3);
        competitionMapper.updateByPrimaryKeySelective(c);
        return JSONReturn.success("操作成功！");
    }

    @Override
    public Integer del(Integer id) {
        return competitionMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Competition selectById(Integer id) {
        return competitionMapper.selectByPrimaryKey(id);
    }

}
