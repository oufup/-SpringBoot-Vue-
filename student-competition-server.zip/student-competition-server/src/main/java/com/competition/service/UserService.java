package com.competition.service;

import com.competition.common.dto.LoginDto;
import com.competition.common.vo.CountVo;
import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.User;
import jakarta.servlet.http.HttpSession;

import java.util.List;
import java.util.Map;


/**
 * 学生服务类
 */
public interface UserService {


    /**
     * 管理员登录
     * @param loginDto
     * @param session
     * @return
     */
    JSONReturn login(LoginDto loginDto, HttpSession session);


    /**
     * 学生分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加学生学生
     * @param user
     * @return
     */
    JSONReturn save(User user);


    /**
     * 修改
     * @param user
     * @return
     */
    JSONReturn update(User user);



    /**
     * 删除学生
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询学生信息
     * @param id
     * @return
     */
    User selectById(Integer id);



    /**
     * 所有学生
     * @return
     */
    List<User> findAll();



    /**
     * 统计
     * @return
     */
    CountVo count();


}
