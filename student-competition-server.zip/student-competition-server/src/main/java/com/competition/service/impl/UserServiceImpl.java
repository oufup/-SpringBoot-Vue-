package com.competition.service.impl;

import com.competition.common.dto.LoginDto;
import com.competition.common.vo.*;
import com.competition.entity.*;
import com.competition.mapper.*;
import com.competition.service.UserService;
import com.competition.utils.DateUtils;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 会员服务实现类
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private AdminMapper adminMapper;

    @Autowired
    private TeacherMapper teacherMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private CompetitionMapper competitionMapper;

    @Autowired
    private ApplyMapper applyMapper;

    @Autowired
    private NoticeMapper noticeMapper;

    @Override
    public JSONReturn login(LoginDto loginDto, HttpSession session) {

        String captcha = session.getAttribute("captcha").toString();
        if(!loginDto.getCaptcha().equalsIgnoreCase(captcha)){
            return JSONReturn.failed("验证码错误！");
        }
        LoginVo loginVo = new LoginVo();
        Integer role = loginDto.getRole();
        if(role == 0){
            Admin admin = adminMapper.selectByUsername(loginDto.getUsername());
            if (admin == null) {
                return JSONReturn.failed("账户不存在！");
            }
            if (!admin.getPassword().equals(loginDto.getPassword())) {
                return JSONReturn.failed("密码错误！");
            }
            BeanUtils.copyProperties(admin, loginVo);
        }else if(role == 1){
            Teacher teacher = teacherMapper.selectByUsername(loginDto.getUsername());
            if (teacher == null) {
                return JSONReturn.failed("账户不存在！");
            }
            if (!teacher.getPassword().equals(loginDto.getPassword())) {
                return JSONReturn.failed("密码错误！");
            }
            BeanUtils.copyProperties(teacher, loginVo);
        }else if(role == 2){
            User user = userMapper.selectByUsername(loginDto.getUsername());
            if (user == null) {
                return JSONReturn.failed("账户不存在！");
            }
            if (!user.getPassword().equals(loginDto.getPassword())) {
                return JSONReturn.failed("密码错误！");
            }
            BeanUtils.copyProperties(user, loginVo);
        }
        loginVo.setRole(role);
        return JSONReturn.success("登录成功！",loginVo);
    }

    @Override
    public PageVo page(Map map) {
        List<User> list = userMapper.findList(map);
        Integer total = userMapper.findTotal(map);
        return new PageVo(total, list);
    }

    @Override
    public JSONReturn save(User user) {
        //账号查询
        User exist = userMapper.selectByUsername(user.getUsername());
        if (exist != null) {
            return JSONReturn.failed("账号已存在，请重新输入！");
        }
        Date date = new Date();
        user.setStatus(0);
        //初始化性别
        user.setSex(0);
        user.setCreateTime(date);
        user.setUpdateTime(date);
        userMapper.insert(user);
        return JSONReturn.success("注册成功！");
    }

    @Override
    public JSONReturn update(User user) {

        User u = userMapper.selectByPrimaryKey(user.getId());
        if (user.getUsername() != null && !u.getUsername().equals(user.getUsername())) {
            User exist = userMapper.selectByUsername(user.getUsername());
            if (exist != null) {
                return JSONReturn.failed("工号已存在，请重新输入！");
            }
        }
        user.setUpdateTime(new Date());
        userMapper.updateByPrimaryKeySelective(user);
        return JSONReturn.success("保存成功！");
    }


    @Override
    public Integer del(Integer id) {
        return userMapper.deleteByPrimaryKey(id);
    }

    @Override
    public User selectById(Integer id) {
        return userMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }


    @Override
    public CountVo count() {

        CountVo countVo = new CountVo();
        List<Notice> noticeList = noticeMapper.findLatestTopList(2);
        List<CompetitionVo> competitionList = new ArrayList<>();
        List<Category> list = categoryMapper.findAll();
        if(!CollectionUtils.isEmpty(list)){
            for(Category category : list){
                CompetitionVo vo = new CompetitionVo();
                Integer totalNum = competitionMapper.countByCategory(category.getId());
                vo.setName(category.getCategoryName());
                vo.setValue(totalNum == null ? 0 : totalNum);
                competitionList.add(vo);
            }
        }
        //获取过去7天未签到考勤
        String[] days = DateUtils.getPast7Days();
        List<Integer> applyNumList =  new ArrayList<>();
        for(String day : days){
            String beginTime = day + " 00:00:00";
            String endTime = day + " 23:59:59";
            Integer applyNum = applyMapper.countByDate(beginTime,endTime);
            applyNumList.add(applyNum == null ? 0 : applyNum);
        }
        countVo.setNoticeList(noticeList);
        countVo.setCompetitionList(competitionList);
        countVo.setDayList(days);
        countVo.setApplyNumList(applyNumList);
        return countVo;
    }

}
