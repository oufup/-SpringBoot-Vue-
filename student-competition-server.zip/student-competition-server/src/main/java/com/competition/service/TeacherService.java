package com.competition.service;

import com.competition.common.vo.JSONReturn;
import com.competition.common.vo.PageVo;
import com.competition.entity.Teacher;

import java.util.List;
import java.util.Map;


/**
 * 教师服务类
 */
public interface TeacherService {
    
    /**
     * 教师分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加教师教师
     * @param teacher
     * @return
     */
    JSONReturn save(Teacher teacher);


    /**
     * 修改
     * @param teacher
     * @return
     */
    JSONReturn update(Teacher teacher);



    /**
     * 删除教师
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询教师信息
     * @param id
     * @return
     */
    Teacher selectById(Integer id);



    /**
     * 所有教师
     * @param collegeId
     * @return
     */
    List<Teacher> findByCollege(Integer collegeId);


}
