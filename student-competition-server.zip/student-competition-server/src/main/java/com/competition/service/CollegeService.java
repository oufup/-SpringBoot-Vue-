package com.competition.service;

import com.competition.common.vo.PageVo;
import com.competition.entity.College;

import java.util.List;
import java.util.Map;

/**
 * 学院服务类
 */
public interface CollegeService {

    /**
     * 学院分页
     * @param map
     * @return
     */
    PageVo page(Map map);

    /**
     * 添加学院
     * @param college
     * @return
     */
    Integer save(College college);

    /**
     * 更新学院
     * @param college
     * @return
     */
    Integer update(College college);


    /**
     * 删除学院
     * @param id
     * @return
     */
    Integer del(Integer id);



    /**
     * 根据ID查询学院
     * @param id
     * @return
     */
    College selectById(Integer id);


    /**
     * 查询所有学院
     * @return
     */
    List<College> findAll();



}
