package com.competition.service.impl;

import com.competition.common.vo.PageVo;
import com.competition.entity.College;
import com.competition.mapper.CollegeMapper;
import com.competition.service.CollegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 学院服务实现类
 */
@Service
public class CollegeServiceImpl implements CollegeService {

    @Autowired
    private CollegeMapper collegeMapper;

    @Override
    public PageVo page(Map map) {
        List<College> list = collegeMapper.findList(map);
        Integer total = collegeMapper.findTotal(map);
        return new PageVo(total,list);
    }

    @Override
    public Integer save(College college) {
        Date date = new Date();
        college.setCreateTime(date);
        college.setUpdateTime(date);
        return collegeMapper.insert(college);
    }

    @Override
    public Integer update(College college) {
        college.setUpdateTime(new Date());
        return collegeMapper.updateByPrimaryKeySelective(college);
    }

    @Override
    public Integer del(Integer id) {
        return collegeMapper.deleteByPrimaryKey(id);
    }

    @Override
    public College selectById(Integer id) {
        return collegeMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<College> findAll() {
        return collegeMapper.findAll();
    }
}
